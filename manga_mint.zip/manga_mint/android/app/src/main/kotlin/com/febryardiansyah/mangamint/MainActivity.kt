package com.febryardiansyah.mangamint

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
