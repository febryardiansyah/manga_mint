const String BaseUrl = 'https://ai-mangaapi.herokuapp.com/api/';
