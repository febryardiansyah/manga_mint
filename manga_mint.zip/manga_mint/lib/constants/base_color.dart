import 'package:flutter/material.dart';

class BaseColor{
  static final Color red = Color(0xffE8505B);
  static final Color black = Color(0xff333333);
  static final Color green = Color(0xff27AE60);
  static final Color orange = Color(0xffF2994A);
  static final Color grey1 = Color(0xff828282);
  static final Color grey2 = Color(0xffC4C4C4);
}